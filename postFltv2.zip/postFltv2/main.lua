---------------------------------------------------------------------------
-- Post Flight Review V2 Widget
-- EdgeTX 2.11+
---------------------------------------------------------------------------

local name = "postFltv2"

---------------------------------------------------------------------------
-- OPTIONS
---------------------------------------------------------------------------

local options = {
  { "T1", SOURCE, 0 },
  { "T2", SOURCE, 0 },
  { "T3", SOURCE, 0 },
  { "T4", SOURCE, 0 },
  { "T5", SOURCE, 0 },
  { "T6", SOURCE, 0 },
  { "T7", SOURCE, 0 },
  { "T8", SOURCE, 0 },
  { "Motor", SOURCE, 0 },
  { "Arm", SOURCE, 0 },
}

---------------------------------------------------------------------------
-- CREATE / UPDATE
---------------------------------------------------------------------------

local function create(zone, opts)
  return {
    zone = zone,
    options = opts or {}
  }
end

local function update(widget, opts)
  widget.options = opts
end

---------------------------------------------------------------------------
-- REFRESH
---------------------------------------------------------------------------

local function refresh(widget)
  local z   = widget.zone
  local opt = widget.options

  lcd.drawFilledRectangle(z.x, z.y, z.w, z.h, COLOR_BLACK)

  lcd.drawText(z.x + z.w / 2,z.y + 14,"POST FLIGHT REVIEW",CENTER + DBLSIZE + WHITE)

  -------------------------------------------------------------------------
  -- MODEL CONNECTED (HARD-CODED TO 1RSS)
  -------------------------------------------------------------------------

  local rss = getValue("1RSS")
  local modelConnected = rss ~= nil and rss ~= 0

  -------------------------------------------------------------------------
  -- CIRCULAR LAYOUT
  -------------------------------------------------------------------------

  local centerY = z.y + 100
  local centerY2 = z.y + 185
  local rMed, spacing = 40, 10

  local totalW = rMed*2*4 + spacing*3
  local startX = z.x + (z.w - totalW) / 2

  local vbatCX = startX + rMed 
  local vbecCX = vbatCX + rMed + spacing + rMed
  local rssCX  = vbecCX + rMed + spacing + rMed
  local rqlyCX = rssCX  + rMed + spacing + rMed

  local tescCX = startX + rMed 
  local tbecCX = tescCX + rMed + spacing + rMed
  local rpmCX  = tbecCX + rMed + spacing + rMed
  local currCX = rpmCX  + rMed + spacing + rMed

  lcd.drawFilledCircle(vbatCX, centerY, rMed, GREY)
  lcd.drawCircle(vbatCX, centerY, rMed, RED)
  lcd.drawCircle(vbatCX, centerY, rMed, RED)
  lcd.drawFilledCircle(vbecCX,  centerY, rMed, GREY)
  lcd.drawCircle(vbecCX, centerY, rMed, RED)
  lcd.drawCircle(vbecCX, centerY, rMed, RED)
  lcd.drawFilledCircle(rssCX,  centerY, rMed, GREY)
  lcd.drawCircle(rssCX, centerY, rMed, RED)
  lcd.drawCircle(rssCX, centerY, rMed, RED)
  lcd.drawFilledCircle(rqlyCX,  centerY, rMed, GREY)
  lcd.drawCircle(rqlyCX, centerY, rMed, RED)
  lcd.drawCircle(rqlyCX, centerY, rMed, RED)

  lcd.drawFilledCircle(tescCX, centerY2, rMed, GREY)
  lcd.drawCircle(tescCX, centerY2, rMed, RED)
  lcd.drawCircle(tescCX, centerY2, rMed, RED)
  lcd.drawFilledCircle(tbecCX,  centerY2, rMed, GREY)
  lcd.drawCircle(tbecCX, centerY2, rMed, RED)
  lcd.drawCircle(tbecCX, centerY2, rMed, RED)
  lcd.drawFilledCircle(rpmCX,  centerY2, rMed, GREY)
  lcd.drawCircle(rpmCX, centerY2, rMed, RED)
  lcd.drawCircle(rpmCX, centerY2, rMed, RED)
  lcd.drawFilledCircle(currCX,  centerY2, rMed, GREY)
  lcd.drawCircle(currCX, centerY2, rMed, RED)
  lcd.drawCircle(currCX, centerY2, rMed, RED)

---------------------------------------------------------------------------
-- VALUES INSIDE CIRCLE
---------------------------------------------------------------------------

local sources = { opt.T1, opt.T2, opt.T3, opt.T4, opt.T5, opt.T6, opt.T7, opt.T8 }
local centers = { vbatCX, vbecCX, rssCX, rqlyCX, tescCX, tbecCX, rpmCX, currCX  }

for i = 1, 8 do
  local src = sources[i]

  if src ~= 0 then
    local info = getSourceInfo(src)

    if info and info.name then
      local baseName = info.name

      -- Read EdgeTX telemetry min/max
      local minVal = getValue(baseName .. "-") or 0
      local maxVal = getValue(baseName .. "+") or 0

      local noDecimals =
        baseName == "1RSS" or
        baseName == "RQly" or
        baseName == "Tesc" or
        baseName == "Tbec" or
        baseName == "RPM"

      local fmt = noDecimals and "%d/%d" or "%.2f/%.2f"

      local y =
        (i <= 4)
        and (centerY - 10)
        or (centerY2 - 10)

      lcd.drawText(
        centers[i],
        y,
        string.format(fmt, minVal, maxVal),
        CENTER + SMLSIZE +
        (modelConnected and YELLOW or WHITE)
      )
    end
  end
end

for i = 1, 4 do
  local info = getFieldInfo(sources[i])
  local name = info and info.name or ""
  lcd.drawText(centers[i], centerY + 10, name, CENTER + SMLSIZE + WHITE)
end

for i = 5, 8 do
  local info = getFieldInfo(sources[i])
  local name = info and info.name or ""
  lcd.drawText(centers[i], centerY2 + 10, name, CENTER + SMLSIZE + WHITE)
end

---------------------------------------------------------------------------
-- MOTOR / ARM TILES
---------------------------------------------------------------------------

local centerY3 = z.y + 232
local h, w, spacing = 40, 200, 0  

local totalW = w*2 + spacing
local startX = z.x + (z.w - totalW) / 2

local motorX = startX
local armX   = startX + w + spacing

local textY = centerY3 + h/2


-- MOTOR 
local activeM = false
local bgColorM = GREY

if opt.Motor ~= 0 then
  activeM = getValue(opt.Motor) > 0 
  bgColorM = activeM and RED or GREEN
end

--ARM
local activeA = false
local bgColorA = GREY

if opt.Arm ~= 0 then
  activeA = getValue(opt.Arm) > 0 
  bgColorA = activeA and RED or GREEN
end

--If CONNECT BGCOLOR CHANGES FOR BOTH TILES
if modelConnected then
  lcd.drawFilledRectangle(motorX, centerY3, w, h, bgColorM)
  lcd.drawFilledRectangle(armX, centerY3, w, h, bgColorA)
end

--DRAW MOTOR AND ARM TILES AND TEXT
lcd.drawRectangle(motorX, centerY3, w, h, WHITE)
lcd.drawText(motorX + w/2, textY, activeM and "MOTOR ON" or "MOTOR OFF", CENTER + VCENTER + MIDSIZE + WHITE)

lcd.drawRectangle(armX,   centerY3, w, h, WHITE)
lcd.drawText(armX + w/2, textY, activeA and "ARMED"    or "DISARMED",  CENTER + VCENTER + MIDSIZE + WHITE)


end
---------------------------------------------------------------------------

return {
  name     = name,
  create  = create,
  update  = update,
  refresh = refresh,
  options = options
}